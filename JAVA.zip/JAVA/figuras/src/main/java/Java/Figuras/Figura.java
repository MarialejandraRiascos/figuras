package Java.Figuras;

public abstract class Figura 
{
    public abstract Double calcularPerimetro();
    public abstract Double calcularArea();
}
